ChatRooms = new Meteor.Collection("chatrooms");
audioCall = new Mongo.Collection('audioCall');
videoCall = new Mongo.Collection('videoCall');

// import { Mongo } from 'meteor/mongo';
// export const ChatRooms = new Meteor.Collection("chatrooms");
