ChatRooms = new Meteor.Collection("chatrooms");
audioCall = new Mongo.Collection('audioCall');

// import { Mongo } from 'meteor/mongo';
// export const ChatRooms = new Meteor.Collection("chatrooms");
